<?php
require_once (dirname(__DIR__) . '/byadposition.class.php');
class byAdPosition_mysql extends byAdPosition {}