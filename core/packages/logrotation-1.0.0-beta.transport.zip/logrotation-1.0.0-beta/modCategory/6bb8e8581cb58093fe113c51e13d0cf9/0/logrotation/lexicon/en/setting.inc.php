<?php

$_lang['area_logrotation_main'] = 'Main';

$_lang['setting_logrotation_size'] = 'Max log size';
$_lang['setting_logrotation_size_desc'] = 'Log file will be cutted by this size (in Bytes)';