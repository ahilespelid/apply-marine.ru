<?php

/**
 * @package logrotation
 */
class logRotationItem extends xPDOSimpleObject
{
}