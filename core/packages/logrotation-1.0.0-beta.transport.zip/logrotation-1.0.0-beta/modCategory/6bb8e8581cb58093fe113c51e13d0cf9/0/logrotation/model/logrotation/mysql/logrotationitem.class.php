<?php
require_once (dirname(__DIR__) . '/logrotationitem.class.php');
class logRotationItem_mysql extends logRotationItem {}