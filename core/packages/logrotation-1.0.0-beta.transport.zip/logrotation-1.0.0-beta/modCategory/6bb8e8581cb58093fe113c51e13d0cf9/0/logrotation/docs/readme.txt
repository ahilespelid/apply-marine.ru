--------------------
logRotation
--------------------
Author: Ilya Utkin <ilyautkin@mail.ru>
--------------------

MODX addon for rotation error.log file