<?php

$_lang['area_logrotation_main'] = 'Основные';

$_lang['setting_logrotation_size'] = 'Максимальный размер';
$_lang['setting_logrotation_size_desc'] = 'Лог-файл будет обрезан до этого размера (в байтах)';