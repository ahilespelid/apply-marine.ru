<?php

$_lang['md_prop_input'] = 'The type of device: Standard, Tablet or Mobile';
