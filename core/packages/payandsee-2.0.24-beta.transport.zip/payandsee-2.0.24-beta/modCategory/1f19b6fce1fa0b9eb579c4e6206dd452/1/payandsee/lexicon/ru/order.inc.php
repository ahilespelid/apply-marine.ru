<?php

$_lang['payandsee_order_cost'] = 'Итого';
$_lang['payandsee_order_submit'] = 'Оплатить';
$_lang['payandsee_order_agree'] = 'Согласен с обработкой персональных данных';

$_lang['payandsee_order_err_delivery'] = 'Вы должны выбрать способ доставки';
$_lang['payandsee_order_err_requires'] = 'Вы должны заполнить требуемые поля';
$_lang['payandsee_err_order_nf'] = 'Заказ с таким идентификатором не найден.';

