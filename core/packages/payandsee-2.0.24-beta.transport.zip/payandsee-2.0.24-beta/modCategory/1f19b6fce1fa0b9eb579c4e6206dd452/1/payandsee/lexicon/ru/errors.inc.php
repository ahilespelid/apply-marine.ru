<?php

/* Errors */

$_lang['payandsee_err_system'] = 'Системная ошибка.';
$_lang['payandsee_err_unknown'] = 'Неизвестная ошибка.';
$_lang['payandsee_err_value'] = 'Неверное значение.';
$_lang['payandsee_err_lock'] = 'Эта операция заблокирована.';
$_lang['payandsee_err_ns'] = 'Это поле обязательно.';
$_lang['payandsee_err_ae'] = 'Это поле должно быть уникально.';
$_lang['payandsee_err_object_nf'] = 'Объект не существует.';
$_lang['payandsee_err_object_exists'] = 'Объект уже существует.';
$_lang['payandsee_err_status_wrong'] = 'Неверный статус.';
$_lang['payandsee_err_term_wrong'] = 'Неверный срок подписки.';
$_lang['payandsee_err_status_same'] = 'Этот статус уже установлен.';


$_lang['PasStatus_err_save'] = 'Не могу сохранить "Статус".';
$_lang['PasContent_err_save'] = 'Не могу сохранить "Контент".';
$_lang['PasClient_err_save'] = 'Не могу сохранить "Клиента".';
$_lang['PasRate_err_save'] = 'Не могу сохранить "Тариф".';
$_lang['PasSubscription_err_save'] = 'Не могу сохранить "Подписку".';
$_lang['PasAccess_err_save'] = 'Не могу сохранить "Доступ".';
