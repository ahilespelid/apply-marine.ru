<?php
class PasContentRate extends xPDOSimpleObject {}