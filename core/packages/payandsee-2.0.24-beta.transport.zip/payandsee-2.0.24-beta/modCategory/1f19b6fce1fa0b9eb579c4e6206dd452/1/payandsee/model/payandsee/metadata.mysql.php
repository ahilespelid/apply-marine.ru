<?php

$xpdo_meta_map = array (
  'xPDOObject' => 
  array (
    0 => 'PasStatus',
    1 => 'PasClient',
  ),
  'xPDOSimpleObject' => 
  array (
    0 => 'PasContent',
    1 => 'PasRate',
    2 => 'PasSubscription',
    3 => 'PasAlert',
  ),
);