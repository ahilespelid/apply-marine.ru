<?php

/** @noinspection PhpIncludeInspection */
require MODX_CORE_PATH . 'model/modx/modparser.class.php';