<?php

$this->customconfigs['cmptabcaption'] = "Setup/Upgrade";
$this->customconfigs['cmptabdescription'] = "Setup/Upgrade MIGX";
$this->customconfigs['cmptabcontroller'] = "setup";