<?php

$winbuttons['cancel']['text'] = "config.cancelBtnText || _('cancel')";
$winbuttons['cancel']['handler'] = 'this.cancel';
$winbuttons['cancel']['scope'] = 'this';

$winbuttons['done']['text'] = "config.saveBtnText || _('done')";
$winbuttons['done']['handler'] = 'this.submit';
$winbuttons['done']['scope'] = 'this';