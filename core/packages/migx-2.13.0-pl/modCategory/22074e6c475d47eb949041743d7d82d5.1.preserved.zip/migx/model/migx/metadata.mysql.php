<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'migxConfig',
    1 => 'migxFormtab',
    2 => 'migxFormtabField',
    3 => 'migxConfigElement',
    4 => 'migxElement',
  ),
);