<?php

include_once 'setting.inc.php';

$_lang['modlastmodified'] = 'modLastModified';
$_lang['modlastmodified_menu_desc'] = 'Пример расширения для разработки.';
$_lang['modlastmodified_items'] = 'Предметы';
$_lang['modlastmodified_item_create'] = 'Создать предмет';
$_lang['modlastmodified_item_err_ae'] = 'Предмет с таким именем уже существует.';
$_lang['modlastmodified_item_err_nf'] = 'Предмет не найден.';
$_lang['modlastmodified_item_err_ns'] = 'Предмет не указан.';
$_lang['modlastmodified_item_err_remove'] = 'Ошибка при удалении Предмета.';
$_lang['modlastmodified_item_err_save'] = 'Ошибка при сохранении Предмета.';
$_lang['modlastmodified_item_remove'] = 'Удалить Предмет';
$_lang['modlastmodified_items_remove'] = 'Удалить Предметы';
$_lang['modlastmodified_items_remove_confirm'] = 'Вы уверены, что хотите удалить эти Предметы?';
$_lang['modlastmodified_item_remove_confirm'] = 'Вы уверены, что хотите удалить этот Предмет?';
$_lang['modlastmodified_item_update'] = 'Изменить Предмет';
$_lang['modlastmodified_intro_msg'] = 'Управляйте вашими предметами.';