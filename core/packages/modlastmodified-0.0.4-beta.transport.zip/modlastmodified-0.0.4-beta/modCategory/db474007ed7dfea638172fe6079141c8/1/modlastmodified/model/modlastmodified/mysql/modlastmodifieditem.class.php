<?php
require_once (dirname(dirname(__FILE__)) . '/modlastmodifieditem.class.php');
class modLastModifiedItem_mysql extends modLastModifiedItem {}