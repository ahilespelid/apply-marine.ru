--------------------
modLastModified
--------------------
Author: Ilya Utkin <ilyautkin@mail.ru>
--------------------

An extra for sending Last-Modified headers