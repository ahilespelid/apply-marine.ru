<?php
/**
 * @package modlastmodified
 */
class modLastModifiedItem extends xPDOSimpleObject {}