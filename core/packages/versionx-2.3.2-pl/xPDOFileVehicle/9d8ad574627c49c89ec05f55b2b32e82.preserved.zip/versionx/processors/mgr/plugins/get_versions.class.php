<?php
require_once dirname(__DIR__) . '/get_versions.class.php';

class VersionXPluginsGetVersionsProcessor extends VersionXGetVersionsProcessor {
    public $classKey = 'vxPlugin';
}
return 'VersionXPluginsGetVersionsProcessor';
