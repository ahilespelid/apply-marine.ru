<?php
require_once (dirname(dirname(__FILE__)) . '/robotsbuilderitem.class.php');
class RobotsBuilderItem_mysql extends RobotsBuilderItem {}