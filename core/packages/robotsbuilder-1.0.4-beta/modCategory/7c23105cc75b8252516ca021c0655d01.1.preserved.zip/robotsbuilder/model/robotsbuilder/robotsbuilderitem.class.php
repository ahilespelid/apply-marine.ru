<?php
class RobotsBuilderItem extends xPDOSimpleObject {}