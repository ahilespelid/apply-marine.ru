<?php

$_lang['area_robotsbuilder_main'] = 'Main';
