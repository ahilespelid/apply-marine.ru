--------------------
RobotsBuilder
--------------------
Author: Ilya Utkin <ilyautkin@mail.ru>
--------------------

MODX Extra for manage robots.txt

Feel free to suggest ideas/improvements/bugs on GitHub:
https://github.com/ilyautkin/RobotsBuilder/issues