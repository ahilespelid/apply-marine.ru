<?php
/**
 * Properties Russian Lexicon Entries for tagCanonical
 *
 * @package tagCanonical
 * @subpackage lexicon
 */

$_lang['tagcanonical_prop_delimiter'] = 'Разделитель для передаваемых GET-параметров';
$_lang['tagcanonical_prop_get'] = 'Список разрешенных GET-параметров, которые будут отображаться в канонической ссылке';
$_lang['tagcanonical_prop_removeParameters'] = 'Отмечаем "Да", если необходимо удалить все GET-параметры из канонической ссылки';