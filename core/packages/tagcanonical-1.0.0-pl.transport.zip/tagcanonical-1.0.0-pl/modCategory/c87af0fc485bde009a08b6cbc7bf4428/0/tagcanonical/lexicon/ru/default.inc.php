<?php
/**
 * Default Russian Lexicon Entries for tagCanonical
 *
 * @package tagCanonical
 * @subpackage lexicon
 */

include_once 'setting.inc.php';
$_lang['tagcanonical'] = 'tagCanonical';