<?php
/**
 * Properties English Lexicon Entries for tagCanonical
 *
 * @package tagCanonical
 * @subpackage lexicon
 */

$_lang['tagcanonical_prop_delimiter'] = 'Separator for GET-parameters passed';
$_lang['tagcanonical_prop_get'] = 'List of allowed GET-parameters to be displayed in the canonical link';
$_lang['tagcanonical_prop_removeParameters'] = 'Mark "Yes" if you need to remove all GET-parameters from the canonical link';