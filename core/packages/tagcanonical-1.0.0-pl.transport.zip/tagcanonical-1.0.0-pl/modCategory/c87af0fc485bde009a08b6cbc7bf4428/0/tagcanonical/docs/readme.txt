--------------------
tagCanonical
--------------------
Author: Sergey Kolesnikov
--------------------

Managing canonical links in MODx Revolution.
Package on GitHub: https://github.com/SSergey-Kolesnikov/tagCanonical