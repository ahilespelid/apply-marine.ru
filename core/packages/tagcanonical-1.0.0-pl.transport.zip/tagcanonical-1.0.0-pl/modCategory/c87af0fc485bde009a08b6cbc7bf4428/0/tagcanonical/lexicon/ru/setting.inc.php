<?php
/**
 * Settings Russian Lexicon Entries for tagCanonical
 *
 * @package tagCanonical
 * @subpackage lexicon
 */

$_lang['setting_tagcanonical_tv'] = 'ID дополнительного поля (TV) для канонических ссылок';
$_lang['setting_tagcanonical_tv_desc'] = 'Укажите ID дополнительного поля (TV), в котором будет указываться список разрешенных GET-параметров.';