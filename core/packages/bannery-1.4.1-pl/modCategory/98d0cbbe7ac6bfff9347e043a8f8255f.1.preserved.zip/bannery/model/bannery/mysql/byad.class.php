<?php
require_once (dirname(__DIR__) . '/byad.class.php');
class byAd_mysql extends byAd {}