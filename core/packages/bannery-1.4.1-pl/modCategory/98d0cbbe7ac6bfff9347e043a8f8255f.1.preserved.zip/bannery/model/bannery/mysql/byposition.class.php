<?php
require_once (dirname(__DIR__) . '/byposition.class.php');
class byPosition_mysql extends byPosition {}