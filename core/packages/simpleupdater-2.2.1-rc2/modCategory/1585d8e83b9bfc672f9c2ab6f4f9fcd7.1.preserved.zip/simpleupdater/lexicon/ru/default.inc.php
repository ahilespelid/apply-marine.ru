<?php

$_lang['simpleupdater'] = 'Обновление MODX';
$_lang['simpleupdater_intro_msg'] = 'После нажатия кнопки «Обновить», будет скачен скрипт для обновления и запущена установка.';
$_lang['simpleupdater_menu'] = 'Обновление MODX';
$_lang['simpleupdater_menu_desc'] = 'Обновить MODX до последней версии';
$_lang['simpleupdater_no_update_available'] = 'MODX уже обновлён до последней версии';
$_lang['simpleupdater_update'] = 'Обновить MODX';
$_lang['simpleupdater_update_start'] = 'Обновить';
