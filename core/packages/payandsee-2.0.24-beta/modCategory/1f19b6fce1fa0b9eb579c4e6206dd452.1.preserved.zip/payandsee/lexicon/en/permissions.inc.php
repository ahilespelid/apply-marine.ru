<?php

$_lang['payandsee_alert_edit'] = 'Разрешает создание\изменение "Оповещения"';
$_lang['payandsee_alert_view'] = 'Разрешает просмотр\вывод "Оповещения"';

$_lang['payandsee_client_edit'] = 'Разрешает создание\изменение "Клиента"';
$_lang['payandsee_client_view'] = 'Разрешает просмотр\вывод "Клиента"';

$_lang['payandsee_content_edit'] = 'Разрешает создание\изменение "Контента"';
$_lang['payandsee_content_view'] = 'Разрешает просмотр\вывод "Контента"';

$_lang['payandsee_rate_edit'] = 'Разрешает создание\изменение "Тарифа"';
$_lang['payandsee_rate_view'] = 'Разрешает просмотр\вывод "Тарифа"';

$_lang['payandsee_status_edit'] = 'Разрешает создание\изменение "Статуса"';
$_lang['payandsee_status_view'] = 'Разрешает просмотр\вывод "Статуса"';

$_lang['payandsee_subscription_edit'] = 'Разрешает создание\изменение "Подписки"';
$_lang['payandsee_subscription_view'] = 'Разрешает просмотр\вывод "Подписки"';

$_lang['payandsee_setting_edit'] = 'Разрешает создание\изменение настроек';
$_lang['payandsee_setting_view'] = 'Разрешает просмотр\вывод настроек';

