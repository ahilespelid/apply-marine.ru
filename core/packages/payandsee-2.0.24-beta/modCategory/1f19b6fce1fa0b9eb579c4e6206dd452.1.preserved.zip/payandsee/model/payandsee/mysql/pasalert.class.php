<?php
require_once (dirname(__DIR__) . '/pasalert.class.php');
class PasAlert_mysql extends PasAlert {}