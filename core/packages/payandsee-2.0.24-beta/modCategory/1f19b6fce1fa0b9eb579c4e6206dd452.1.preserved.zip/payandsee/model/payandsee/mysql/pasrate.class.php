<?php
require_once (dirname(__DIR__) . '/pasrate.class.php');
class PasRate_mysql extends PasRate {}