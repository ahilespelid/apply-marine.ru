<?php
require_once (dirname(__DIR__) . '/pascontent.class.php');
class PasContent_mysql extends PasContent {}