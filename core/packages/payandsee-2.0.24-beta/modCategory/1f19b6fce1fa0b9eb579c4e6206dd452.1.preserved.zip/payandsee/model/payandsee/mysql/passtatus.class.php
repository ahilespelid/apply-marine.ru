<?php
require_once (dirname(__DIR__) . '/passtatus.class.php');
class PasStatus_mysql extends PasStatus {}