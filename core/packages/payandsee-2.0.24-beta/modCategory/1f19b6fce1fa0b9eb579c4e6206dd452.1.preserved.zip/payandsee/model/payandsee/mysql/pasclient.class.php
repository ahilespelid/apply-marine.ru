<?php
require_once (dirname(__DIR__) . '/pasclient.class.php');
class PasClient_mysql extends PasClient {}