<?php
require_once (dirname(__DIR__) . '/passubscription.class.php');
class PasSubscription_mysql extends PasSubscription {}