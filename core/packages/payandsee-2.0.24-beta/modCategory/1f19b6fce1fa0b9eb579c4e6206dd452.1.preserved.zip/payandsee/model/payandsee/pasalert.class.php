<?php
class PasAlert extends xPDOSimpleObject {}