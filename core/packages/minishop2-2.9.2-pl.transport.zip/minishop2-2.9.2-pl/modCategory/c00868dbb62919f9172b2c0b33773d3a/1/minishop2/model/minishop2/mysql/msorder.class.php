<?php
require_once (dirname(__DIR__) . '/msorder.class.php');
class msOrder_mysql extends msOrder {}