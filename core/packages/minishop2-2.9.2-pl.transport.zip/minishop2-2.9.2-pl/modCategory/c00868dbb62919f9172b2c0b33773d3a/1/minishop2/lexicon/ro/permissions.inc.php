<?php

/**
 * Permissions Romanian Lexicon Entries for miniShop2
 * translated by Anna
 *
 *
 * @package minishop2
 * @subpackage lexicon
 */

$_lang['mscategory_save'] = 'Permite crearea \ modificarea categoriei magazinului';
$_lang['msproduct_save'] = 'Permite crearea\ modificarea produsului magazinului ';

$_lang['msorder_view'] = 'Permite vizualizarea comenzii ';
$_lang['msorder_list'] = 'Permite afișarea listei de comenzi';
$_lang['msorder_save'] = 'Permite modificarea comenzii';
$_lang['msorder_remove'] = 'Permite ștergeți comenzii';

$_lang['mssetting_view'] = 'Permite vizualizarea setărilor';
$_lang['mssetting_list'] = 'Permite afișarea unei liste de setări';
$_lang['mssetting_save'] = 'Permite crearea\ modificarea setărilor';

$_lang['msproductfile_save'] = 'Permite crearea\ modificarea fișierelor produsului';
$_lang['msproductfile_generate'] = 'Permite generarea miniaturilor a produsului';
$_lang['msproductfile_list'] = 'Permite afișarea unei liste de fișiere a produsului.';
