<?php
require_once (dirname(__DIR__) . '/msorderstatus.class.php');
class msOrderStatus_mysql extends msOrderStatus {}