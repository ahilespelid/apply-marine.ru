<?php
require_once (dirname(__DIR__) . '/msorderproduct.class.php');
class msOrderProduct_mysql extends msOrderProduct {}