<?php

$_lang['localizatorcontent_list'] = 'Permission to list of localizations';
$_lang['localizatorcontent_view'] = 'Permission to view of localizations';
$_lang['localizatorcontent_save'] = 'Permission to save\update\remove localizations';
