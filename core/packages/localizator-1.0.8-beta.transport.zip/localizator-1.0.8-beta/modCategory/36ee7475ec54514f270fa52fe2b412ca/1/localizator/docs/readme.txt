--------------------
localizator
--------------------
Author: but1head <radionov@me.com>
--------------------

MODx Revolution component for multi language site

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/but1head/localizator/