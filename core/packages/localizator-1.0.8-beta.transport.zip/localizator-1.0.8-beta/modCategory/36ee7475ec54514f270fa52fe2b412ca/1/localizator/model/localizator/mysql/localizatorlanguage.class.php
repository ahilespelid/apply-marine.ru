<?php
require_once (dirname(__DIR__) . '/localizatorlanguage.class.php');
class localizatorLanguage_mysql extends localizatorLanguage {}