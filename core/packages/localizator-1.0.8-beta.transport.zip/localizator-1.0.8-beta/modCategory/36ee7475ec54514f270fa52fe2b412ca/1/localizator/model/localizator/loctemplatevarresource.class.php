<?php
class locTemplateVarResource extends xPDOSimpleObject {}