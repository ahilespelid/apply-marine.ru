<?php

$_lang['localizator_prop_snippet'] = 'Cніпет будзе вызваты для ввода рэзультатаў працы. Па змаўчанні - "pdoResources"';
$_lang['localizator_prop_class'] = 'Аб\'ект. Па змаўчанні - "modResource"';
$_lang['localizator_prop_localizatorTVs'] = 'Тэлевізійны спіс параметраў для ўзору лакалізатара. Значэнне па змаўчанні абрана ў Сістэмных наладах';
$_lang['localizator_prop_localizator_key'] = 'Цяперашняя лакалізацыя па змаўчанні';